require("shinyMethyl") || stop("unable to load shinyMethyl")
BiocGenerics:::testPackage("shinyMethyl")